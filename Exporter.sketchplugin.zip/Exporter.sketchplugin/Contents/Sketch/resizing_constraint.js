var ResizingConstraint = {
  NONE: 0,
  RIGHT: 1 << 0,
  WIDTH: 1 << 1,
  LEFT: 1 << 2,
  BOTTOM: 1 << 3,
  HEIGHT: 1 << 4,
  TOP: 1 << 5
};

