var ResizingType = {
  STRETCH: 0,
  PIN_TO_CORNER: 1,
  RESIZE_OBJECT: 2,
  FLOAT_IN_PLACE: 3
};

